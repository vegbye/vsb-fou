package vsb.kladd.serialization;

@SuppressWarnings("serial")
public class VsbSubSerializable extends VsbSuperSerializable {

    private String b;

    public void setB(String b) {
        this.b = b;
    }

    public String getB() {
        return b;
    }
}
