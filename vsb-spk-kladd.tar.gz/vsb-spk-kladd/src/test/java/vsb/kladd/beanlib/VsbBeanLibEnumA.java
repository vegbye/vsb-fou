package vsb.kladd.beanlib;

public enum VsbBeanLibEnumA {

    HvitVin, RoedVin, RoseVin, PortVin
}
