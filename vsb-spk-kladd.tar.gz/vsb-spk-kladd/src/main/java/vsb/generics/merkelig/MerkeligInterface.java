package vsb.generics.merkelig;

public interface MerkeligInterface {

    public <T extends MerkeligInterface> T lagKopi();

}
