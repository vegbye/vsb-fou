package vsb.generics;

public class MyImplementingClass implements MyGenericsInterface<MyImplementingClass> {

    public MyImplementingClass lagKopi() {
        // TODO Auto-generated method stub
        return new MyImplementingClass();
    }

}
