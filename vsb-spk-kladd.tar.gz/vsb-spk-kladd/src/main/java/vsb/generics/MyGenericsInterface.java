package vsb.generics;

public interface MyGenericsInterface<T> {

    public T lagKopi();
}
