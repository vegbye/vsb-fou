package vsb.kladd;

public class VsbMyClass {

    class Indre {
    }

    static class IndreStatisk {
    }

    @SuppressWarnings("unused")
    private class IndrePrivat {
    }

    @SuppressWarnings("unused")
    private static class IndrePrivatStatisk {
    }
}
