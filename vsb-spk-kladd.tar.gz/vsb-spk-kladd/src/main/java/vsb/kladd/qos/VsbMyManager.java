package vsb.kladd.qos;

public interface VsbMyManager {

    @VsbQos
    public void f();

}
