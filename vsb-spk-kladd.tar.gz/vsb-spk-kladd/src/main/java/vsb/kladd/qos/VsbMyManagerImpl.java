package vsb.kladd.qos;

public class VsbMyManagerImpl implements VsbMyManager {

    public void f() {

    }
}