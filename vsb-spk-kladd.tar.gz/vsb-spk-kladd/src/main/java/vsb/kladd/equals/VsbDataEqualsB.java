package vsb.kladd.equals;

public class VsbDataEqualsB {

    private final String myStreet;

    public VsbDataEqualsB(String myStreet) {
        this.myStreet = myStreet;
    }

    public String getMyStreet() {
        return myStreet;
    }
}
