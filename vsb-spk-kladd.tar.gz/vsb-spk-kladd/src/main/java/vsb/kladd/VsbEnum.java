package vsb.kladd;

public enum VsbEnum {

    START, STOPP
}
