package vsb.kladd;

public class SkjultKode {

    public static void main(String[] args) {
        //
        System.out.println("hei 1");
        System.out.println("hei 2");
    }
}
