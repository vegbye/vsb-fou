package vsb.kladd.spring;

public interface VsbSpringBeanA {

    public void perform();

}
