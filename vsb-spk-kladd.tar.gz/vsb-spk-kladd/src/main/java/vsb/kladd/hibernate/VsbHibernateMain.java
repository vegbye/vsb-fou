package vsb.kladd.hibernate;

public class VsbHibernateMain {

    public static void main(String[] args) {
        //HibernateUtil.getSessionFactory();
    }

}
